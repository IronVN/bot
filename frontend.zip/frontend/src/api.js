const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:3000';

export async function listFiles() {
  const res = await fetch(`${API_BASE}/api/files`);
  if (!res.ok) throw new Error('Failed to fetch files');
  return res.json();
}

export async function uploadFile(file, meta = {}, token) {
  const form = new FormData();
  form.append('file', file);
  Object.keys(meta).forEach(k => form.append(k, meta[k]));
  const headers = token ? { Authorization: `Bearer ${token}` } : {};
  const res = await fetch(`${API_BASE}/api/files/upload`, { method: 'POST', body: form, headers });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || 'Upload failed');
  }
  return res.json();
}