import React from 'react'
import Home from './pages/Home'
import Upload from './pages/Upload'

export default function App(){
  const [route, setRoute] = React.useState('home')
  return (
    <div className="app">
      <nav>
        <button onClick={()=>setRoute('home')}>Home</button>
        <button onClick={()=>setRoute('upload')}>Upload</button>
      </nav>
      <main>
        {route==='home' ? <Home /> : <Upload />}
      </main>
    </div>
  )
}