import React from 'react'
import { listFiles } from '../api'

function FileCard({ f }){
  const thumbUrl = f.thumbnail ? `/thumbs/${f.thumbnail}` : `/uploads/${f.filename}`
  const isVideo = f.type === 'video'
  return (
    <div className="card">
      {isVideo ? (
        <video width="320" height="240" controls src={`/media/video/${f.filename}`} />
      ) : (
        <img src={thumbUrl} alt={f.original_name} width="320" height="240" />
      )}
      <div className="meta">
        <strong>{f.display_name || f.original_name}</strong>
        <p>{f.description}</p>
      </div>
    </div>
  )
}

export default function Home(){
  const [files, setFiles] = React.useState([])
  const [loading, setLoading] = React.useState(true)
  const [err, setErr] = React.useState(null)

  React.useEffect(()=>{
    listFiles().then(data=>{ setFiles(data); setLoading(false) }).catch(e=>{ setErr(e.message); setLoading(false) })
  },[])

  if (loading) return <p>Loading...</p>
  if (err) return <p>Error: {err}</p>
  return (
    <div className="gallery">
      {files.length===0 ? <p>No files yet</p> : files.map(f => <FileCard key={f.id} f={f} />)}
    </div>
  )
}