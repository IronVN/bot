import React from 'react'
import { uploadFile } from '../api'

export default function Upload(){
  const [file, setFile] = React.useState(null)
  const [desc, setDesc] = React.useState('')
  const [name, setName] = React.useState('')
  const [msg, setMsg] = React.useState(null)
  const onSubmit = async (e) => {
    e.preventDefault()
    if (!file) return setMsg('Choose a file')
    try {
      setMsg('Uploading...')
      await uploadFile(file, { description: desc, display_name: name })
      setMsg('Upload successful')
      setFile(null); setDesc(''); setName('')
    } catch (e) { setMsg('Error: ' + e.message) }
  }
  return (
    <form onSubmit={onSubmit} className="upload-form">
      <input type="file" onChange={e=>setFile(e.target.files[0])} />
      <input placeholder="Display name" value={name} onChange={e=>setName(e.target.value)} />
      <textarea placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)} />
      <button type="submit">Upload</button>
      {msg && <p>{msg}</p>}
    </form>
  )
}